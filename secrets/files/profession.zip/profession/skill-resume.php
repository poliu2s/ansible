<ul class="car hideme">
	<?php if ( opt('skill_percent_1') && opt('skill_name_1') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_1'); ?>">
					<span><?php eopt('skill_percent_1'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_1'); ?></p>
			</div>
		</li>
	<?php }  if ( opt('skill_percent_2') && opt('skill_name_2') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_2'); ?>">
					<span><?php eopt('skill_percent_2'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_2'); ?></p>
			</div>
		</li>
	<?php }  if ( opt('skill_percent_3') && opt('skill_name_3') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_3'); ?>">
				<span><?php eopt('skill_percent_3'); ?>%</span>
			</div>
				<p><?php eopt('skill_name_3'); ?></p>
			</div>
		</li>
   <?php }  if ( opt('skill_percent_4') && opt('skill_name_4') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_4'); ?>">
					<span><?php eopt('skill_percent_4'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_4'); ?></p>
			</div>
		</li>
	<?php }  if ( opt('skill_percent_5') && opt('skill_name_5') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_5'); ?>">
					<span><?php eopt('skill_percent_5'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_5'); ?></p>
			</div>
		</li>
	  <?php }  if ( opt('skill_percent_6') && opt('skill_name_6') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_6'); ?>">
					<span><?php eopt('skill_percent_6'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_6'); ?></p>
			</div>
		</li>
	<?php }  if ( opt('skill_percent_7') && opt('skill_name_7') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_7'); ?>">
					<span><?php eopt('skill_percent_7'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_7'); ?></p>
			</div>
		</li>
	<?php }  if ( opt('skill_percent_8') && opt('skill_name_8') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_8'); ?>">
					<span><?php eopt('skill_percent_8'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_8'); ?></p>
			</div>
		</li>
	<?php }  if ( opt('skill_percent_9') && opt('skill_name_9') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_9'); ?>">
					<span><?php eopt('skill_percent_9'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_9'); ?></p>
			</div>
		</li>
	<?php }  if ( opt('skill_percent_10') && opt('skill_name_10') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_10'); ?>">
					<span><?php eopt('skill_percent_10'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_10'); ?></p>
			</div>
		</li>
	<?php }  if ( opt('skill_percent_11') && opt('skill_name_11') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_11'); ?>">
					<span><?php eopt('skill_percent_11'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_11'); ?></p>
			</div>
		</li>
	<?php }  if ( opt('skill_percent_12') && opt('skill_name_12') ) { ?>
		<li>
			<div class="chartbox">
				<div class="chart" data-percent="<?php eopt('skill_percent_12'); ?>">
					<span><?php eopt('skill_percent_12'); ?>%</span>
				</div>
				<p><?php eopt('skill_name_12'); ?></p>
			</div>
		</li>
	<?php } ?>
</ul>