<?php if ( opt('vertical_template') == 0 ) { ?>
	
	<div class="mainpart">	
		<!-- first white part -->
		<div class="cvpage first-block hidden-tablet"></div>
	
<?php } else if  ( opt('vertical_template') == 1 ) {  ?>
	<div class="wrap">
		<div class="container">
			<div class="vertical-mainpart">
<?php }